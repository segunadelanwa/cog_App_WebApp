				<?php
				include("index_header.php");
				?>
<!DOCTYPE html>
<html lang="en">
    <head>
	
		<?php
		include("header.php");
	   
 
				
		?>
			
    </head>
	


<style>

  .img_slide {
  padding-top:10px;
  margin-left:100px;
  width:200px;
  height:350px
  }
    .slide_container {
  border:1px solid #a8538b; 
  margin:50px 50px;
  }
  
  
  
@media (max-width: 776px){

  .img_slide {
  margin-left:10px
  }
  
      .slide_container {
  border:1px solid black; 
  margin:5px 5px;
  }
  
} 
  
  
</style>
	
 

  <body class="sb-nav-fixed">

 	

	 	<div id="modal" class="modal-backdrop loaderDisplayNone"  > 
	<center>  
	 
		<img src="gen_img/loading.gif" style="margin-top:15%; height:150px" /><br />
		 
		<span style="color:white" > Please Wait..</span>
	  
	</center>
	</div>


	
	
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
				<?php
				require("dashboard_head.php");
				?>
        </nav>
		
        <div id="layoutSidenav">
		
            <div id="layoutSidenav_nav">

				<?php
				require("sidebar.php");
				?>
				
		  </div>
           
		   <div id="layoutSidenav_content">
		   
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4"> 
					          <i class="fas fa-book"></i> VIEW EBOOKS
							  </h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>  
                            <li class="breadcrumb-item active">View E-book</li>
                        </ol>
                  
					 
  
                        <div class="row">
						
    						   <div class="col-md-10 slide_container"> 
 				 
					 
					 
	<center>								  
												
												<div  style="display:flex; align-item:center; overflow-y:auto;">
<br />                  
<br />                  
													
     <?php 
	
	$result = $loader-> FetchAllEbookPhoto();	
	
	foreach($result as $active)
	{
 	
			echo'<div class="img_slide"> 
			
	            <h6><b>'.$active['book_name'].'</b></h6>
				<img src="all_photo/'.$active['ebook_photo'].'" style="width:200px; height:250px" />  <br/> 
			    <input onclick="addSubject('.$active['id'].')" class="btn  bg-primary text-white col-md-12" value="View E-Book" />
				
			   </div>
			 ';
 


	  
	} 	

?>                     
		 	</div>
<br />                  
<br />                  
 </div>
 </center>		 								

							
                        </div>
						

				<div id="otpupdatebox" style="background-color:white; padding:15px,15pxpx;margin-top:10px;margin-bottom:50px">


				</div>
				<div id="outputupdate">


				</div>
 
				 
 
				 
				  
				   </div>
				  
				  
                </main>
				
				
				
               
			   <footer class="py-4 bg-light mt-auto">
                   <?php 
				   require("footer.php"); 
				   ?>
                </footer>
				
				
            </div>
			
        </div>
    
    
     
 
 
 
    </body>
</html>


 

<script>

 
 	$(document).on('submit', '#searchForm', function(event){
    event.preventDefault();
	
 
  const ebook_id      = document.getElementById('ebook_id').value; 
 
 alert(ebook_id);
/*	  

		 
*/		
	});






</script>

<script>
 const elementmodal  = document.getElementById('modal'); 
 
function addSubject(val1) {
 
	// alert(val1);
	
				$.ajax({
				url:"pageajax.php",
				method:"POST",
				data:{ 
				ebook_id:val1,
				page:'subjectSetup',
				action:'loanEbook'
				},
				beforeSend:function()
				{

				elementmodal.classList.remove('loaderDisplayNone');
				elementmodal.classList.add('loaderDisplayblock');

				},
				success:function(data)
				{
					
				elementmodal.classList.remove('loaderDisplayblock');
				elementmodal.classList.add('loaderDisplayNone');
				
				$('#otpupdatebox').append(data);

				  

				}
			});	
 
 

}


</script>



 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


