				<?php
				include("index_header.php");
				?>
<!DOCTYPE html>
<html lang="en">
    <head>
	
		<?php
		include("header.php");
	   
	   				if(isset($_GET["today"]))
					{
						
						$todayDevotion ='';
					   $today = $_GET["today"];
					   
					   
						if(!empty($today))
						{
							$todayDevotion = $_GET["today"];
							
						}else{
							
							$todayDevotion = "";
						}
				
				}
				
				
		?>
			
    </head>
	



	
 

  <body class="sb-nav-fixed">

 	

	 	<div id="modal" class="modal-backdrop loaderDisplayNone"  > 
	<center>  
	 
		<img src="gen_img/loading.gif" style="margin-top:15%; height:150px" /><br />
		 
		<span style="color:white" > Please Wait..</span>
	  
	</center>
	</div>


	
	
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
				<?php
				require("dashboard_head.php");
				?>
        </nav>
		
        <div id="layoutSidenav">
		
            <div id="layoutSidenav_nav">

				<?php
				require("sidebar.php");
				?>
				
		  </div>
           
		   <div id="layoutSidenav_content">
		   
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4"> 
					          <i class="fas fa-book"></i> Daily Devotions Yoruba
						</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>  
							<li  class="breadcrumb-item"><a href="view_devotion_eng.php?today=<?php echo $loader->DevotionsDay(); ?>">View Devotion(Eng)</a></li>
                            <li class="breadcrumb-item active"> Daily Devotions Yoruba</li>
                        </ol>
                  
					 
  
						   <div class="col-md-12"> 
 				 
					 
					 
									  
												
												<div class="card-body">
													
													<div class="table-responsive">
														

 		 	 <form id="searchForm" method="POST" Action="">
	 

			   <div class="form-row">
			   
				   <div class="form-group col-md-6">
					   <label for="name">Select Devotion Date</label>
					   															<div class="form-group"> 
															<div style="display:flex;" class="input-group"><br>

																  <select id="devotion_day_set"  name="devotion_day_set" required="required" aria-required="true"style="height:25px;" >
																		<option disabled="disabled" selected="selected">Day</option>
																		<option>01</option>
																		<option>02</option>
																		<option>03</option>
																		<option>04</option>
																		<option>05</option>
																		<option>06</option>
																		<option>07</option>
																		<option>08</option>
																		<option>10</option>
																		<option>11</option>
																		<option>12</option>
																		<option>13</option>
																		<option>14</option>
																		<option>15</option>
																		<option>16</option>
																		<option>17</option>
																		<option>18</option>
																		<option>19</option>
																		<option>20</option>
																		<option>21</option>
																		<option>22</option>
																		<option>23</option>
																		<option>24</option>
																		<option>25</option>
																		<option>26</option>
																		<option>27</option>
																		<option>28</option>
																		<option>29</option>
																		<option>30</option>
																		<option>31</option> 
																		
							 
																	</select>&nbsp;&nbsp;

																	<select id="devotion_month_set"  name="devotion_month_set" required="required" aria-required="true"style="height:25px;">
																		<option disabled="disabled" selected="selected">Month</option>
																		<option value="01">Jan</option>
																		<option value="02">Feb</option>
																		<option value="03">Mar</option>
																		<option value="04">Apr</option>
																		<option value="05">May</option>
																		<option value="06">Jun</option>
																		<option value="07">Jul</option>
																		<option value="08">Aug</option> 
																		<option value="09">Sep</option>
																		<option value="10">Oct</option>
																		<option value="11">Nov</option>
																		<option value="12">Dec</option>                  
							 
																	</select>&nbsp;&nbsp;

															 
																  <select id="devotion_year_set"  name="devotion_year_set" required="required" aria-required="true"style="height:25px;">
																  <option disabled="disabled" selected="selected">Year</option>
																  <option>2050</option>
																  <option>2049</option>
																  <option>2048</option>
																  <option>2047</option>
																  <option>2046</option>
																  <option>2045</option>
																  <option>2044</option>
																  <option>2043</option>
																  <option>2042</option>
																  <option>2041</option>
																  <option>2040</option>
																  <option>2039</option>
																  <option>2038</option>
																  <option>2037</option>
																  <option>2036</option>
																  <option>2035</option>
																  <option>2034</option>
																  <option>2033</option>
																  <option>2032</option>
																  <option>2031</option>
																  <option>2030</option>
																  <option>2029</option>
																  <option>2028</option>
																  <option>2027</option>
																  <option>2026</option>
																  <option>2025</option>
																  <option>2024</option>
																  <option>2023</option>
															
																

																	</select>&nbsp;&nbsp;
																		   
															</div>
														</div> 

				   </div>

 

			   </div>
             

			
			<input  type="submit" id="nameSearch" name="" class="btn btn-warning" value="Search Devotion" /> 
			<a href="view_devotion_yor.php"  class="btn btn-primary ">
			<i class="fa fa-spinner fa-spin fa-1x fa-fw"></i>
			Refresh   
			</a>			
			

			
		   </form>
		   
		   


				   
													</div>
										
										</div>
										 
					  
	                      
 </div>
 
				<div id="otpupdatebox" style="background-color:white; padding:15px,15pxpx;margin-top:10px;margin-bottom:50px">


				</div>
				<div id="outputupdate">


				</div>
 
				 
 
				 
				  
				   </div>
				  
				  
                </main>
				
				
				
               
			   <footer class="py-4 bg-light mt-auto">
                   <?php 
				   require("footer.php"); 
				   ?>
                </footer>
				
				
            </div>
			
        </div>
    
    
     
 
 
 
    </body>
</html>


<script>
  var elementmodal = document.getElementById('modal');

 var	todayDevotion = "<?php echo $todayDevotion; ?>";

 
		 
				$.ajax({
				url:"pageajax.php",
				method:"POST",
				data:{ 
				    todayDevotion:todayDevotion,
					page:'subjectSetup',
					action:'checkDevotionYor'
					},
			
				beforeSend:function()
				{

				elementmodal.classList.remove('loaderDisplayNone');
				elementmodal.classList.add('loaderDisplayblock');

				},
				success:function(data)
				{
					
				elementmodal.classList.remove('loaderDisplayblock');
				elementmodal.classList.add('loaderDisplayNone');

				$('#otpupdatebox').append(data);
				
				$('#nameSearch').attr('disabled', true); 
				$('#nameSearch').removeClass('btn-warning');
				$('#nameSearch').addClass('btn-success');
				$('#nameSearch').text('Search success'); 
				 
				}
			});	






</script>



<script>
  var elementmodal = document.getElementById('modal');


 	$(document).on('click', '#nameSearch', function(event){
    event.preventDefault();
	
    const	devotion_day_set   = document.getElementById("devotion_day_set").value; 
    const	devotion_month_set = document.getElementById("devotion_month_set").value; 
    const	devotion_year_set  = document.getElementById("devotion_year_set").value; 

	 	//alert(devotion_year_set+'-'+devotion_month_set+'-'+devotion_day_set);
	 	var todayDevotion = devotion_year_set+'-'+devotion_month_set+'-'+devotion_day_set;
 	
				$.ajax({
				url:"pageajax.php",
				method:"POST",
				data:{ 
				todayDevotion:todayDevotion,
				page:'subjectSetup',
				action:'checkDevotionYor'
				},
				beforeSend:function()
				{

				elementmodal.classList.remove('loaderDisplayNone');
				elementmodal.classList.add('loaderDisplayblock');

				},
				success:function(data)
				{
					
				elementmodal.classList.remove('loaderDisplayblock');
				elementmodal.classList.add('loaderDisplayNone');
				
				$('#otpupdatebox').append(data);

				$('#nameSearch').attr('disabled', true); 
				$('#nameSearch').removeClass('btn-warning');
				$('#nameSearch').addClass('btn-success');
				$('#nameSearch').text('Search success'); 

				}
			});	
		 
		
	});






</script>



 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


