<?php


$string = "logo.png";

//print_r (explode(".",$string));
print_r (implode(".",$string));
/*
if("18" <  "4"){
	
	echo "True";
}else{
	
    echo "False";
}
	
	
	
//	$rand = rand(0, 11);	
// $randPhoto ="https://cityofgoddevotions.com/devotion_Photo/nature$rand.jpg";
//echo$current_date  = date('Y-m-d');	
//echo$current_date  = date('Y-m-d');	

*/
?>