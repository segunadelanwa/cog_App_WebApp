<!DOCTYPE html>
<html lang="en">
    <head>
				<?php
				require("header.php");
				// ADMIN STAFF
				?>




    </head>
<style>

  .img_slide {
  padding-top:10px;
  margin-left:100px;
  width:200px;
  height:350px
  }
    .slide_container {
  border:1px solid #a8538b; 
  margin:50px 50px;
  }
  
  
  
@media (max-width: 776px){

  .img_slide {
  margin-left:10px
  }
  
      .slide_container {
  border:1px solid #a8538b; 
  margin:5px 5px;
  }
  
} 
  
  
</style>

	
	
    <body class="sb-nav-fixed" >
	
	 	<div id="modal" class="modal-backdrop loaderDisplayNone"  > 
	<center>  
	 
		<img src="gen_img/loading.gif" style="margin-top:15%; height:150px" /><br />
		 
		<span style="color:white" >Ebook Uploading Processing..</span>
	  
	</center>
	</div>





        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
				<?php
				require("dashboard_head.php");
				?>
        </nav>
		
        <div id="layoutSidenav">
		
            <div id="layoutSidenav_nav">

				<?php
				require("sidebar.php");
				?>
				
		  </div>
           
		   <div id="layoutSidenav_content">
		   
                <main>
                    <div class="container-fluid">
                        <h4 class="mt-4">
						
						DAILY DEVOTIONS / E-BOOKS MANAGMENT DASHBOARD
						</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">  HOME</li>
                        </ol>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
								
                                    <div class="card-body"><center><h2 ><?php echo $loader-> DisplayEbookActiveSubsciber();	?> </h2></center>E-BOOKS ACTIVE SUBSCRIBER</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>


                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
								
                                    <div class="card-body"><center><h2 ><?php echo $loader-> DisplayEbookPassiveSubsciber();	?> </h2> </center> E-BOOKS PASSIVE SUBSCRIBER </div> 
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>

							
							 <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
							
                                    <div class="card-body">	<center><h2 ><?php echo $loader-> DisplayTotalVoucherRow();	?></h2></center>COUPONS  CREATED </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
								
                                    <div class="card-body"><center><h2 ><?php echo $loader-> DisplayAdminRow();	?> </h2></center>REGISTERED ADMIN</div> 
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
							



                        </div>
						
                        <div class="row">
						
    						   <div class="col-md-10 slide_container"> 
 				 
					 
					 
	<center>								  
												
												<div  style="display:flex; align-item:center; overflow-y:auto;">
<br />                  
<br />                  
													
     <?php 
	
	$result = $loader-> FetchAllEbookPhoto();	
	$DevotionsDay = $loader->DevotionsDay();	
	
	foreach($result as $active)
	{
 	  $book_link = $active['book_link'];
			echo'<div class="img_slide"> 
			
	            <h6><b>'.$active['book_name'].'</b></h6>
				<img src="all_photo/'.$active['ebook_photo'].'" style="width:200px; height:250px" />  <br/>
			    <a href="'.$book_link.'"> <div class="btn  bg-primary text-white col-md-12"><b> View E-Book</b></div>	 </a>
			   </div>
			 ';
 


	  
	} 	

?>                     
		 	</div>
<br />                  
<br />                  
 </div>
 </center>		 								

							
                        </div>
						
						
						
						
						
				    	<div class="card mb-4">
                             <div class="card-header bg bg-primary text-white">
                                <i class="fas fa-table mr-1"></i>
                               <h3>Active E-book Subscibers </h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                       
                                   
                                        <thead>
                                            <tr>
                                                <th>Phone </th> 
                                                <th>Email </th> 
                                                <th>Fullname </th> 
                                                <th>Sub Date</th> 
                                                <th>Sub Expires</th>
                                                <th>Sub Status </th>
                                                <th>Registered Date</th> 
                                                
                                            </tr>
                                        </thead> 
                                        <tbody> 
     <?php 
	
	$result = $loader-> FetchAllActiveSubscriber();	
	
	foreach($result as $active)
	{
 	
			echo'<tr role="row" class="odd">
		 
				<td>'.$active['phone'].'  </td>   
				<td>'.$active['email'].' </td>
				<td>'.$active['fullname'].' </td>
				<td>'.$active['sub_date'].' </td>  
				<td>'.$active['sub_expire'].' </td>  
				<td>'.$active['status'].' </td>  
				<td>'.$active['date'].' </td>  
			   
			   
					 
				</td> 
				 
			</tr>
			';
 


	  
	} 	

?>                     
                                        
                                        </tbody>
                                   
								                                    
								  </table>
                                </div>
                            </div>
                        </div>
						
						
						
                        <div class="card mb-4">
                            <div class="card-header bg bg-warning text-white">
                                <i class="fas fa-table mr-1"></i>
                                <h3>Passive E-book Subscibers </h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable4" width="100%" cellspacing="0">
                                       
                                   
                                      <thead>
                                            <tr>
                                                <th>Phone </th> 
                                                <th>Email </th> 
                                                <th>Fullname </th> 
                                                <th>Sub Date</th> 
                                                <th>Sub Expires</th>
                                                <th>Sub Status </th>
                                                <th>Registered Date</th> 
                                                
                                            </tr>
                                        </thead> 
                                        <tbody> 
     <?php 
	
	$result = $loader-> FetchAllPassiveSubscriber();	
	
	foreach($result as $active)
	{
 	
			echo'<tr role="row" class="odd">
		 
				<td>'.$active['phone'].'  </td>   
				<td>'.$active['email'].' </td>
				<td>'.$active['fullname'].' </td>
				<td>'.$active['sub_date'].' </td>  
				<td>'.$active['sub_expire'].' </td>  
				<td>'.$active['status'].' </td>  
				<td>'.$active['date'].' </td>  
			   
			   
					 
				</td> 
				 
			</tr>
			';
 


	  
	} 	

?>                     
                                             
                                        </tbody>
                                   
								      		                                    
								  </table>
                                </div>
                            </div>
                        </div>
                    
      				

						
                        <div class="card mb-4">
                            <div class="card-header bg bg-success text-white">
                                <i class="fas fa-table mr-1"></i>
                               <h3> All Created Coupon Code  </h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable_2" width="100%" cellspacing="0">
                                       
                                   
                                        <thead>
                                            <tr>
                                                <th>Coupon Code</th> 
                                                <th>Coupon Access </th> 
                                                <th>Voucher Active Date </th> 
                                                <th>Voucher Date Expires </th> 
                                                <th>Coupon Uploader</th> 
                                                <th>Date Uploaded</th> 
                                                <th>Delete Coupon</th> 
                                                
                                            </tr>
                                        </thead> 
                                        <tbody> 
     <?php 
	
	$result = $loader-> FetchVoucher();	
	
	foreach($result as $active)
	{ 	
		 
			
			echo'<tr role="row" class="odd">
		         
 
				<td>'.$active['voucher_code'].' </td>
				<td>'.$active['user_access'].'-User(s) </td> 
				<td class="bg bg-success">'.$active['voucher_date_active'].' </td> 
				<td class="bg bg-danger">'.$active['voucher_date_expires'].' </td> 
				<td>'.$active['creator'].' </td>   
				<td>'.$active['date_uploaded'].' </td> 
				<td>
			   <a href="#"  > <div class="btn btn-danger"onclick="deleteCoupon(this)" data-animal-type="'.$active['voucher_code'].'">Delete ?</div></a>
		       </td>
				 
			</tr>
			';
 


	  
	} 


?>                     
                                        
                                        </tbody>
                                   
								                                    
								  </table>
                                </div>
                            </div>
                        </div>
       
	   
                        <div class="card mb-4">
                            <div class="card-header bg bg-danger text-white">
                                <i class="fas fa-table mr-1"></i>
                               <h3>COG Admins  </h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable3" width="100%" cellspacing="0">
                                       
                                   
                                        <thead>
                                            <tr>
                                                <th>Photo </th>
                                                <th>Username</th> 
                                                <th>fullname</th>
                                                <th>Phone </th> 
                                                <th>Gender</th>
											    <th>Acct Status</th>
											    <th>Acct Admin</th>
											    <th>Reg Date</th>
											    <th>Delete Admin</th>
                                                
                                            </tr>
                                        </thead> 
                                        <tbody> 
 
     <?php 
	//<a href="#"  > <div class="btn btn-danger"onclick="showDetails(this)" data-animal-type="'.$active['username'].'">Delete Admin</div></a>
	$result = $loader-> FetctAllAdmin();	
	$placeholder ="";
	foreach($result as $active)
	{  
			
			if($active['photo'] == "placeholder.jpg"){
				$placeholder = "placeholder.PNG";
			}else{
				
				$placeholder = $active['photo'];
 
			}
			
			echo'<tr role="row" class="odd">
		 
				<td>  
				<img src="all_photo/'.$placeholder.'"  style="height:70px"   />
				</td> 
				 
				<td>'.$active['username'].' </td> 
				<td>'.$active['fullname'].' </td> 
				<td>'.$active['phone'].' </td> 
				<td>'.$active['gender'].' </td> 
				<td>'.$active['acct_level'].' </td> 
				<td>'.$active['registrar'].' </td> 
				<td>'.$active['date_reg'].' </td> 
			    <td > 
					
				</td> 
				 
			
			
 
 

					<div class="col-md-4 modal-grids  ">
						<div class="modal fade" id="disapproveMaintenance" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
						
						 					<a href="#"  > <div class="btn btn-danger" data-toggle="modal" data-target="#disapproveMaintenance">Delete Admin</div></a>
						
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										
									</div>
									
										<div class="modal-body"> 
                                         <center class="text-danger">  DELETE ADMIN   </center><hr />										
												<div class="row">
													<div class="col-sm-9">Are you sure you want to delete Admin account ?    </div>
											   </div>  
										</div>
										
									<div class="modal-footer">
										<button type="button" class="btn btn-success" data-dismiss="modal">Cancel</button>
										<button type="button" class="btn btn-danger" onclick="showDetails(this)" data-animal-type="'.$active['username'].'"   name="approveDelete" >Delete</button>
									</div>
								</div> 
							</div> 
						</div> 
					</div>
					
					</tr>
	';
	  
	} 	 
?>                     
                                      
                                        </tbody>
                                   
								                                    
								  </table>
                                </div>
                            </div>
                        </div>
                    
  


					
				  </div>
				  
  <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>



                </main>
               
			   <footer class="py-4 bg-light mt-auto">
                   <?php 
				     require("footer.php"); 
				   ?>
                </footer>
				
				
            </div>
        </div>
    
       
        <script src="js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
		
        <script src="js/scripts.js"></script>
        <script src="js/Chart.min.js" crossorigin="anonymous"></script>
        
       
		
        <script src="js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/datatables-demo.js"></script>
		  
		
		
    </body>
</html>
<script>

 
function showDetails(animal) {

  var elementmodal = document.getElementById('modal');

	
  var admin_user = animal.getAttribute("data-animal-type");
 // alert("The " + animal.innerHTML + " is a " + admin_user + ".");
  
 
 

		$.ajax({
			url:"pageajax.php",
			method:"POST",
			data:{
				admin_user:admin_user,   
				page:'admin_signup_page',
				action:'deleteAdmin'
				},
				dataType:"json",
				beforeSend:function()
				{
					
				elementmodal.classList.remove('loaderDisplayNone');
				elementmodal.classList.add('loaderDisplayblock');
				  
				},
				success:function(data)
				{
					 
					  
					  if(data.success == 'success')
						  {
							 
							elementmodal.classList.remove('loaderDisplayblock');
							elementmodal.classList.add('loaderDisplayNone');	
							   alert(data.feedback);
							   window.location="index.php";
							
					 
						  }else{
							   
							elementmodal.classList.remove('loaderDisplayblock');
							elementmodal.classList.add('loaderDisplayNone');	
							alert(data.feedback);
							//window.location.reload();

						   
						  }



				}
				
				
			  })
	 

  
}	
   
function deleteCoupon(animal) {

  var elementmodal = document.getElementById('modal');

	
  var couponCode = animal.getAttribute("data-animal-type");
 // alert("The " + animal.innerHTML + " is a " + admin_user + ".");
  
 
 

		$.ajax({
			url:"pageajax.php",
			method:"POST",
			data:{
				couponCode:couponCode,   
				page:'admin_signup_page',
				action:'deleteCoupon'
				},
				dataType:"json",
				beforeSend:function()
				{
					
				elementmodal.classList.remove('loaderDisplayNone');
				elementmodal.classList.add('loaderDisplayblock');
				  
				},
				success:function(data)
				{
					 
					  
					  if(data.success == 'success')
						  {
							 
							elementmodal.classList.remove('loaderDisplayblock');
							elementmodal.classList.add('loaderDisplayNone');	
							   alert(data.feedback);
							   window.location="index.php";
							
					 
						  }else{
							   
							elementmodal.classList.remove('loaderDisplayblock');
							elementmodal.classList.add('loaderDisplayNone');	
							alert(data.feedback);
							//window.location.reload();

						   
						  }



				}
				
				
			  })
	 

  
}	
   



  
 </script> 
 

	
	
<script>

function addSubject(val1) {
	
 	
	alert(val1);
/*	
 			$.ajax({
				url:"../pageajax.php",
				method:"POST", 
				data:{
					stu_online_id:val2,   
					subject_id:val1,   
					page:'subjectSetup',
					action:'updateSubjectID'
					}, 
				success:function(data)
				{
	                 
						  alert(data);
						  //location.href='student_subject_.php?student_id='+val2;
						  
					 
				 
				}
			});	
 
 */

}



</script>	
	
	
	
