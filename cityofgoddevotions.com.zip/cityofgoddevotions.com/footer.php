<?php
//footer.php


$date             = date('Y'); 

echo'
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy;CAC City Of God Devotions '.$date.'</div>
                            <div>
                             
                            </div>
                        </div>
                    </div>
                </footer>
	';			
				
?>