
  <?php
 
  
header('content-type:	application/json;');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Max-Age: 1000");
header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Origin, Cache-Control, Pragma, Authorization, Accept, Accept-Encoding");
header("Access-Control-Allow-Methods: PUT, POST, GET, OPTIONS, DELETE");



$homedb = mysqli_connect ('localhost', 'root',  '',  'cityofg1_cog_church_db');	 
//$homedb = mysqli_connect ('cityofgoddevotions.com', 'cityofg1_adminuser',  'cityofg1_cog_church_db@@@123123',  'cityofg1_cog_church_db');	 
	 	 
/*
living_water.jpeg
life_in_the_grave.jpeg
divine_instruction.jpeg
pillers_of_faith.jpeg
power_of_success.jpeg
positive_change.jpeg
power_of_kobo.jpeg
mystery_of_dream.jpeg
the_strength_of_visition.jpeg
the_needs_forthe_needy.jpeg
The_role_of_challenges_successful_business.jpeg
the_limited_plus_the_unlimited.jpeg
643ebc3f56a8e.jpg
*/
include('config.php');
 
$loader = new Loader(); 
 
 



if($_GET["action"] == 'offlineDevotion')
{ 
 
    	$data = $loader->FetchApiDevotionsEngOffline();	
		
 					 
  $data;	  
}



if($_GET["action"] == 'SearchDevotions')
{ 
 
        $encode = file_get_contents('php://input');
        $decode = json_decode($encode, true);
        
        $todayDevotion =  $_GET['dateSearch']; 

  
    	$data = $loader->FetchApiDevotionsEng($todayDevotion);	
		
 					 
  $data;	  
}




if($_GET["action"] == 'SearchDevotionsYor')
{ 
 
         $encode = file_get_contents('php://input');
        $decode = json_decode($encode, true);
        
        $todayDevotion =  $_GET['dateSearch']; 
 						 

	$data = $loader->FetchApiDevotionsYor($todayDevotion);	
		
 					 
  $data;	  
}


if($_GET["action"] == 'FetchAllEbookPhoto')
{ 
  
 						 

 $data = $loader->ApiFetchAllEbookPhoto();		
		
 					 
  $data;	  
}


if($_GET["action"] == 'SubscriberSignup')
{ 
  
        $encode = file_get_contents('php://input');
        $decode = json_decode($encode, true);
        
        $email    =  $decode['email']; 						 
        $fullname =  $decode['fullname']; 						 
        $phone    =  $decode['phone']; 						 
        $date     =  date('Y-m-d');
        
            $double_user_exist = $loader->CheckSubscriber($email);
            
             	if($double_user_exist == 0)  
				{

                                    $query_insert =("INSERT INTO book_subscriber VALUE (
                                    '',  
                                    '".mysqli_real_escape_string($homedb, $phone)."',  
                                    '".mysqli_real_escape_string($homedb, $email)."',  
                                    '".mysqli_real_escape_string($homedb, $fullname)."',   
                                    '".mysqli_real_escape_string($homedb, '')."',   
                                    '".mysqli_real_escape_string($homedb, '')."',
                                    '".mysqli_real_escape_string($homedb, '')."', 
                                    '".mysqli_real_escape_string($homedb, '')."',
                                    '".mysqli_real_escape_string($homedb, 'beneficiaries')."', 
                                    '".mysqli_real_escape_string($homedb, '')."', 
                                    '".mysqli_real_escape_string($homedb, $date)."' 
                                    )");
                                    
                                                      

									if(mysqli_query($homedb, $query_insert))
									{
									    
                                            $data[] = array(
                                            
                                            'success'    => 'ok', 
                                            'feedback'   =>	" $fullname your ebook subscriber account created successfully!",
                                            'email'      =>  $email, 
                                            'fullname'   =>  $fullname, 
                                            'phone'      =>  $phone, 
                                            'sub_amt'    => '',
                                            'sub_status' => '',
                                            'date_text'  => '',
                                            'sub_month'  => '',
                                            'sub_bene'   => 'beneficiaries',
                                            'sub_id'     => '',
                                            'date'       =>  $date
                                            
                                            );									    
									}else{
									    
                        					$data[] = array(
                        					'success'  =>  'error', 
                        					'feedback'  => 'Newwork err please try again '
                        					);									    
									}	
				    
		
		
				}
				else if($double_user_exist == 1)
				{
				
				
																
                    $loader->query = "SELECT * FROM `book_subscriber` WHERE `book_subscriber`.`phone`='$phone' AND `book_subscriber`.`email` ='$email' ";
                    $result = $loader->query_result();
				 
                        foreach($result as $row){
                        
           	
                        
                                            $data[] = array( 
                                                
                                                'success'    => 'ok', 
                                                'feedback'   =>	"Ebook subscriber account created successfully!",
                                                'email'      => $row['email'],
                                                'fullname'   => $row['fullname'], 
                                                'phone'      => $row['phone'], 
                                                'sub_amt'    => $row['sub_amt'],
                                                'sub_status' => $row['status'],
                                                'date_text'  => $row['date_text'],
                                                'sub_month'  => $row['sub_month'],
                                                'sub_bene'   => $row['sub_bene'],
                                                'sub_id'     => $row['subscription_id'],
                                                'date'       => $row['date'],
                                                
                                            );	
                        }
                
				}
				else 
				{
				
				
																
					$data[] = array(
					'success'  =>  'error', 
					'feedback'  =>  "Subscriber account doesn't exist "
					);
				
				}
	 
  $data;	  
}


if($_GET['action'] == 'SubscriberPayment')
{
 

        $encode = file_get_contents('php://input');
        $decode = json_decode($encode, true);

		$voucher_code        =  $loader->VoucherCode();
		$current_date        = date('Y-m-d');
		$date_text           = date('d/m/Y');
		
		
		$fullname         = $decode['fullname'];
		$phone            = $decode['phone'];
		$sub_month        = $decode['month'];
		$amount           = $decode['amount'];
		$email            = $decode['email'];
		$sub_bene         = $decode['bene'];
		 
		  $voucher_date_active  = date('Y-m-d');	 
		  $voucher_date_expires = date('Y-m-d',   strtotime("+ $sub_month month"));	  

 	$email_exist =  $loader->CheckSubscriber($email);
 
						 
								   $query_wallet =("INSERT INTO voucher VALUE (
									'',
									'".mysqli_real_escape_string($homedb, $voucher_code)."',	 									 
									'".mysqli_real_escape_string($homedb, $phone)."',	 									 
									'".mysqli_real_escape_string($homedb, $voucher_date_active)."',	 									 
									'".mysqli_real_escape_string($homedb, $voucher_date_expires)."', 	
									'".mysqli_real_escape_string($homedb, $current_date)."',
									'".mysqli_real_escape_string($homedb, $sub_bene)."',
									'".mysqli_real_escape_string($homedb, $amount)."'
									)");
									if(mysqli_query($homedb,$query_wallet))
									{
											if(	$email_exist === 0)		
						                    {
						                        
                                                        $query_insert =("INSERT INTO book_subscriber VALUE (
                                                        '',  
                                                        '".mysqli_real_escape_string($homedb, $phone)."',  
                                                        '".mysqli_real_escape_string($homedb, $email)."',  
                                                        '".mysqli_real_escape_string($homedb, $fullname)."',   
                                                        '".mysqli_real_escape_string($homedb, $voucher_code)."',   
                                                        '".mysqli_real_escape_string($homedb, $sub_bene)."',
                                                        '".mysqli_real_escape_string($homedb, $sub_month)."', 
                                                        '".mysqli_real_escape_string($homedb, $date_text)."',
                                                        '".mysqli_real_escape_string($homedb, 'subscriber')."', 
                                                        '".mysqli_real_escape_string($homedb, $amount)."', 
                                                        '".mysqli_real_escape_string($homedb, $voucher_date_active)."' 
                                                        )");
                                                        
                                                        mysqli_query($homedb, $query_insert);
                                                        
                                                        
                                                        
                                                        $data[] = array(
                                                        'success'		=>	'ok',
                                                        'feedback'		=>	"COG ebooks subscription payment received. $fullname your ebook subscriber account created successfully!"
                                                        );
                                                
                                                
						                    }
						                    else
						                    {
						                        
                                                        $query_wallet ="UPDATE `book_subscriber` SET  
                                                        `subscription_id` = '$voucher_code', 
                                                        `sub_bene`    = '$sub_bene', 
                                                        `sub_month`   = '$sub_month', 
                                                        `date_text`   = '$date_text', 
                                                        `status`      = 'subscriber', 
                                                        `sub_amt`     = '$amount'
                                                        WHERE `book_subscriber`.`email` = '$email'"; 
                                                        
                                                        mysqli_query($homedb,$query_wallet); 
                                                        
                                                
                                                        $data[] = array(
                                                        'success'		=>	'ok',
                                                        'feedback'		=>	"COG ebooks subscription payment received. $fullname your ebook subscriber payment updated"
                                                        );
        
						                    }
							

    								}
    								else
    								{
    									
    									 $data[] = array(
    											'success'		=>	'failed',
    											'feedback'		=>	"Newtwork error"
    										);
    								}
			 

	 

 
	

 
 $data;
 
}

			 
 if($_GET["action"] == 'FetchClickedEbook')
{ 
 
       
// $digit = $_GET['ebookid'];
	$data = $loader->FetchClickedEbbok($_GET['ebookid']);	
		
 					 
  $data;	  
}

 
 
// echo json_encode($data, JSON_PRETTY_PRINT);
 echo json_encode($data);
 //echo $data;
 
?>