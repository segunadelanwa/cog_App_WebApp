
<!DOCTYPE html>
<html lang="en">
    <head>
	
		<?php
		require("header.php");
		?>
			
    </head>
	
		<?php
		require("index_header.php");
		?>
    <body class="sb-nav-fixed">

 	
 	<div id="modal" class="modal-backdrop loaderDisplayNone"  > 
	<center>  
	 
		<img src="gen_img/loading.gif" style="margin-top:15%; height:150px" /><br />
		 
		<span style="color:white" >Ebook Uploading Processing..</span>
	  
	</center>
	</div>



 

 



        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
				<?php
				require("dashboard_head.php");
				?>
        </nav>
		
        <div id="layoutSidenav">
		
            <div id="layoutSidenav_nav">

				<?php
				require("sidebar.php");
				?>
				
		  </div>
           
		   <div id="layoutSidenav_content">
		   
		   



         <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">
						
						<i class="fas fa-book"></i> ADD E-BOOK
						</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active"> Add ebook</li>
                        </ol>
                  
					  

                       

						   <div class="col-xl-8"> 
						 

										<div class="card mb-4">
												<div class="card-header">
													<i class="fas fa-book"></i>
												 ADD EBOOK FORM
												</div>
												<div class="card-body">
													<div class="table-responsive">
														  <form method="POST"   id="user_register_form">
														  
															<div class="form-group">	
															<label> E-Book Photo   </label>
                                                            <input class="form-control" placeholder="Book Name"   type="file" name="ebook_photo" id="ebook_photo" required />

															</div>

															<div class="form-group">	
															<label> Book Title  </label>
                                                          <input class="form-control" placeholder="Book Name"   type="text" name="book_name" id="book_name" required />

															</di


															<div class="form-group">	
															<label> Book Contents  </label>
                                                          <input class="form-control" placeholder="Book Name"   type="text" name="book_content" id="book_content" required />

															</div>


															<div class="form-group">	
															<label>Book  Introduction  </label>
															<textarea type="text" name="introduction"  id="introduction" class="form-control"  ></textarea>
															</div>


															<div class="form-group">	
															<label>About Book     </label>
															<textarea type="text" name="about_book"  id="about_book" class="form-control"  ></textarea>
															</div>



        													<div class="form-group">	
															<label>Book Chapter 1     </label>
															<textarea type="text" name="chapter_0"  id="chapter_0" class="form-control"  ></textarea>
															</div>

															 

															 <div class="form-group">	
															<label>Book Chapter 2     </label>
															<textarea type="text" name="chapter_1"  id="chapter_1" class="form-control"  ></textarea>
															</div>



        													<div class="form-group">	
															<label>Book Chapter 3     </label>
															<textarea type="text" name="chapter_2"  id="chapter_2" class="form-control"  ></textarea>
															</div>

															 

															 <div class="form-group">	
															<label>Book Chapter 4     </label>
															<textarea type="text" name="chapter_3"  id="chapter_3" class="form-control"  ></textarea>
															</div>

															 															 
																

        													<div class="form-group">	
															<label>Book Chapter 5     </label>
															<textarea type="text" name="chapter_4"  id="chapter_4" class="form-control"  ></textarea>
															</div>

															 

															 <div class="form-group">	
															<label>Book Chapter 6     </label>
															<textarea type="text" name="chapter_5"  id="chapter_5" class="form-control"  ></textarea>
															</div>



        													<div class="form-group">	
															<label>Book Chapter 7     </label>
															<textarea type="text" name="chapter_6"  id="chapter_6" class="form-control"  ></textarea>
															</div>

															 

															 <div class="form-group">	
															<label>Book Chapter 8     </label>
															<textarea type="text" name="chapter_7"  id="chapter_7" class="form-control"  ></textarea>
															</div>

															 
															 
															 
			        										<div class="form-group">	
															<label>Book Chapter 9     </label>
															<textarea type="text" name="chapter_8"  id="chapter_8" class="form-control"  ></textarea>
															</div>

															 

															 <div class="form-group">	
															<label>Book Chapter 10     </label>
															<textarea type="text" name="chapter_9"  id="chapter_9" class="form-control"  ></textarea>
															</div>

															 
															 
															 
															 
															 
															 
															 
															 
															 

															<div class="form-group">	
															<label> Admin Uploader  </label>
                                                          <input class="form-control" value="<?php echo"$username"; ?>"  type="text" name="admin_uploader" id="admin_uploader" readonly required />

															</div>															 


 
 
												 
																   
																	
																	<input type="hidden" name="page"   value='admin_signup_page' />
																	<input type="hidden" name="action" value="e_book_upload" />

																	<input type="submit" name="admin_signup" id="admin_signup" class="btn btn-primary" value="Upload Ebook">
																</div>
															</form>
													</div>
												</div>
														 
					 				
						 </div>
					  
	                    
		  
				 
				  </div>
                </main>
  
				
            </div>
        </div>
    
    
        <script src="js/scripts.js"></script>
    
   
 
    </body>
</html>


<script>
 
 


 $(document).ready(function(){

  var elementmodal = document.getElementById('modal');

  $('#user_register_form').parsley();

  $('#user_register_form').on('submit', function(event){
    event.preventDefault();



    if($('#user_register_form').parsley().validate())
    {
			  $.ajax({
				url:'pageajax.php',
				method:"POST",
				data:new FormData(this),
				dataType:"json",
				contentType:false,
				cache:false,
				processData:false, 
				beforeSend:function()
				{
					
				elementmodal.classList.remove('loaderDisplayNone');
				elementmodal.classList.add('loaderDisplayblock');
				  
				},
				success:function(data)
				{
					 
					  
					  if(data.success == 'success')
						  {
							 
							elementmodal.classList.remove('loaderDisplayblock');
							elementmodal.classList.add('loaderDisplayNone');	
							   alert(data.feedback);
							   window.location="view_ebook.php";
							
					 
						  }else{
							   
							elementmodal.classList.remove('loaderDisplayblock');
							elementmodal.classList.add('loaderDisplayNone');	
							alert(data.feedback);
							//window.location.reload();

						   
						  }



				}
				
				
			  })
    }

  });
	
});




</script>






