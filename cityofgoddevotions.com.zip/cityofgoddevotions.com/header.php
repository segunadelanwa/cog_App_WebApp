<?php
//header.php
?>

 
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
 
    <meta name="author" content="CAC CITY OF GOD DEVOTIONS  " /> 
	<title>CAC CITY OF GOD DEVOTIONS  </title>
	<link href="css/styles.css" rel="stylesheet" /> 	
 	<link rel="apple-touch-icon" href="all_photo/logo.png" />
	<link rel="shortcut icon"    href="all_photo/logo.png"/>	
    
	<meta name="theme-color"    content="#a8538b"> 
	 
	<meta name="msapplication-TileImage" content='https://cityofgoddevotions.com/all_photo/logo.png'>
	<meta property='og:url'              content='https://cityofgoddevotions.com/'>
	<meta property='og:site_name'        content='CAC CITY OF GOD DEVOTIONS'  />  
	<meta property='og:title'            content='CAC CITY OF GOD DEVOTIONS'  />
	<meta name="twitter:image"           content='https://cityofgoddevotions.com/all_photo/logo.png' />
	<meta property="og:type"             content="website">
	<meta property="og:image"            content='https://cityofgoddevotions.com/all_photo/logo.png'>
	<meta property="og:image:secure_url" content='https://cityofgoddevotions.com/all_photo/logo.png'>
	<meta property='og:description'      content='CAC CITY OF GOD DEVOTIONS  ' >
	<meta property="og:image:type"       content="image/jpeg" />
	<meta property="og:image:width"      content="300">
	<meta property="og:image:height"     content="200">
	<meta property='al:ios:url'          content='https://cityofgoddevotions.com/all_photo/logo.png'>
	<meta property='al:ios:app_store_id' content=''>
	<meta property='fb:app_id'           content='232273500911428'>


	
	 
    <script src="js/all.min.js" crossorigin="anonymous"></script>
	<script src="scripts/jquery.min.js"></script>
	<script src="scripts/parsley.js"></script>
	<script src="scripts/popper.min.js"></script>
	<script src="scripts/bootstrap.min.js"></script>
	<script src="scripts/jquery.dataTables.min.js"></script>
	<script src="scripts/dataTables.bootstrap4.min.js"></script>
	
	
 
