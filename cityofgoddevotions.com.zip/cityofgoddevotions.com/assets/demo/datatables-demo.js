// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable();
});


// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable_2').DataTable();
});


// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable3').DataTable();
});

// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable4').DataTable();
});
// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable5').DataTable();
});
