
<!DOCTYPE html>
<html lang="en">
    <head>
	
		<?php
		require("header.php");
		?>
			
    </head>
	
		<?php
		require("index_header.php");
		?>
    <body class="sb-nav-fixed">

 	
 	<div id="modal" class="modal-backdrop loaderDisplayNone"  > 
	<center>  
	 
		<img src="gen_img/loading.gif" style="margin-top:15%; height:150px" /><br />
		 
		<span style="color:white" > Devotion Upload Processing..</span>
	  
	</center>
	</div>


 

 



        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
				<?php
				require("dashboard_head.php");
				?>
        </nav>
		
        <div id="layoutSidenav">
		
            <div id="layoutSidenav_nav">

				<?php
				require("sidebar.php");
				?>
				
		  </div>
           
		   <div id="layoutSidenav_content">
		   
		   



         <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">
						
					<i class="fas fa-book"></i> DAILY DEVOTIONS
						</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active"> Add devotion</li>
                        </ol>
                  
					  

                       

						   <div class="col-xl-12"> 
						 

										<div class="card mb-4">
												<div class="card-header">
													<i class="fas fa-book"></i>
												  Devotion Upload Form
												</div>
												
												<div class="card-body ">
													<div class="table-responsive">
													
														  <form method="POST"   id="user_register_form" class="col-xl-10">
														  
														  
 

															<div class="form-group">			
															<label>Set Devotion Date</label> 
															<div style="display:flex;" class="input-group"><br>

																  <select id="devotion_day_set"  name="devotion_day_set" required="required" aria-required="true"style="height:25px;" >
																		<option disabled="disabled" selected="selected">Day</option>
																		<option>01</option>
																		<option>02</option>
																		<option>03</option>
																		<option>04</option>
																		<option>05</option>
																		<option>06</option>
																		<option>07</option>
																		<option>08</option>
																		<option>09</option>
																		<option>10</option>
																		<option>11</option>
																		<option>12</option>
																		<option>13</option>
																		<option>14</option>
																		<option>15</option>
																		<option>16</option>
																		<option>17</option>
																		<option>18</option>
																		<option>19</option>
																		<option>20</option>
																		<option>21</option>
																		<option>22</option>
																		<option>23</option>
																		<option>24</option>
																		<option>25</option>
																		<option>26</option>
																		<option>27</option>
																		<option>28</option>
																		<option>29</option>
																		<option>30</option>
																		<option>31</option> 
																		
							 
																	</select>&nbsp;&nbsp;

																	<select id="devotion_month_set"  name="devotion_month_set" required="required" aria-required="true"style="height:25px;">
																		<option disabled="disabled" selected="selected">Month</option>
																		<option value="01">Jan</option>
																		<option value="02">Feb</option>
																		<option value="03">Mar</option>
																		<option value="04">Apr</option>
																		<option value="05">May</option>
																		<option value="06">Jun</option>
																		<option value="07">Jul</option>
																		<option value="08">Aug</option> 
																		<option value="09">Sep</option>
																		<option value="10">Oct</option>
																		<option value="11">Nov</option>
																		<option value="12">Dec</option>                  
							 
																	</select>&nbsp;&nbsp;

															 
																  <select id="devotion_year_set"  name="devotion_year_set" required="required" aria-required="true"style="height:25px;">
																  <option disabled="disabled" selected="selected">Year</option>
																  <option>2050</option>
																  <option>2049</option>
																  <option>2048</option>
																  <option>2047</option>
																  <option>2046</option>
																  <option>2045</option>
																  <option>2044</option>
																  <option>2043</option>
																  <option>2042</option>
																  <option>2041</option>
																  <option>2040</option>
																  <option>2039</option>
																  <option>2038</option>
																  <option>2037</option>
																  <option>2036</option>
																  <option>2035</option>
																  <option>2034</option>
																  <option>2033</option>
																  <option>2032</option>
																  <option>2031</option>
																  <option>2030</option>
																  <option>2029</option>
																  <option>2028</option>
																  <option>2027</option>
																  <option>2026</option>
																  <option>2025</option>
																  <option>2024</option>
																  <option>2023</option>
															
																

																	</select>&nbsp;&nbsp;
																		   
															</div>
														</div> 


   <hr />

<div style="display: flex" >
															<div class="form-group">			
 															<label>Devotion Topic (English)  </label>
															<input type="text" name="devotion_topic_english"   id="devotion_topic_english" class="form-control"     required />
															</div>


															<div class="form-group ml-5">			
 															<label>Devotion Topic (Yoruba)  </label>
															<input type="text" name="devotion_topic_yoruba"   id="devotion_topic_yoruba" class="form-control"    required />
															</div>
</div>


<div style="display: flex" >
															<div class="form-group">			
 															<label>Devotion Text (English)  </label> <br /> 
															<input type="text" name="devotion_text_english"   id="devotion_text_english" class="form-control"    required />
															</div>


															<div class="form-group ml-5">			
 															<label>Devotion Text (Yoruba)  </label>  <br /> 
															<input type="text" name="devotion_text_yoruba"   id="devotion_text_yoruba" class="form-control"    required />
															</div>
</div>


<div style="display: flex" >
															<div class="form-group">			
 															<label>Text Reading   (English)  </label>   <br />
															<textarea type="text" name="text_reading_english"  id="text_reading_english" class="form-control"  required></textarea>
															</div>


															<div class="form-group ml-5">			
 															<label>Text  Reading (Yoruba)  </label> <br />
															<textarea type="text" name="text_reading_yoruba"  id="text_reading_yoruba" class="form-control"  required></textarea>
															</div>
</div>

	
	
<div style="display: flex" >
															<div class="form-group">			
 															<label>Devotion  Prayer (English)  </label>   <br />
															<textarea type="text" name="devotion_prayer_english"  id="devotion_prayer_english" class="form-control"  required></textarea>
															</div>


															<div class="form-group ml-5">			
 															<label>Devotion  Prayer Text (Yoruba)  </label> <br />
															<textarea type="text" name="devotion_prayer_yoruba"  id="devotion_prayer_yoruba" class="form-control"  required></textarea>
															</div>
</div>

												 

 

														 
 

 

														 

															<div class="form-group">	 
															<input type="hidden" name="tier1" value="tier1"  id="tier1" class="form-control" required />
															</div>

 
												 
																   
																	
																	<input type="hidden" name="page"   value='admin_signup_page' />
																	<input type="hidden" name="action" value="devotion_upload" />

																	<input type="submit" name="admin_signup" id="admin_signup" class="btn btn-primary" value="Upload Devotion">
																</div>
															</form>
													</div>
												</div>
														 
					 				
						 </div>
					  
	                    
		  
				 
				  </div>
                </main>
  
				
            </div>
        </div>
    
    
        <script src="js/scripts.js"></script>
    
   
 
    </body>
</html>


 
<script>
 
 


 $(document).ready(function(){

  var elementmodal = document.getElementById('modal');



  window.ParsleyValidator.addValidator('checkemail', {
    validateString: function(value){
      return $.ajax({
        url:'pageajax.php',
        method:'POST',
        data:{page:'admin_signup_page', action:'check_parrent_reg', email:value},
        dataType:"json",
        async: false,
        success:function(data)
        {
          return true;
        }
      });
    }
  });

  $('#user_register_form').parsley();

  $('#user_register_form').on('submit', function(event){
    event.preventDefault();

 

    if($('#user_register_form').parsley().validate())
    {
      $.ajax({
        url:'pageajax.php',
        method:"POST",
        data:new FormData(this),
        dataType:"json",
        contentType:false,
        cache:false,
        processData:false,
				beforeSend:function()
				{
					
				elementmodal.classList.remove('loaderDisplayNone');
				elementmodal.classList.add('loaderDisplayblock');
				  
				},
				success:function(data)
				{
					 
					  
					  if(data.success == 'success')
						  {
							 
							elementmodal.classList.remove('loaderDisplayblock');
							elementmodal.classList.add('loaderDisplayNone');	
							   alert(data.feedback);
							  // window.location="../";
							
					 
						  }else{
							   
							elementmodal.classList.remove('loaderDisplayblock');
							elementmodal.classList.add('loaderDisplayNone');	
							alert(data.feedback);
							//window.location.reload();

						   
						  }



				}  

		
      })
    }

  });
	
});

 
</script>






