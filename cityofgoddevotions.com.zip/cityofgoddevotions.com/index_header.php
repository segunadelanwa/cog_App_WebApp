<?php
ob_start();
include"config.php";



 
$loader = new Loader();
$time = time(); 
$update_time = date('Y-m-d');
$update = date('Y-m-d');

if(isset($_SESSION['password']) AND !empty($_SESSION['username']))
{
  
   $loader->query='SELECT * FROM `login_table` WHERE `password`="'.$_SESSION['password'].'" AND `username`="'.$_SESSION['username'].'"';
		
		 if($result = $loader->query_result()){
	 
		
			foreach($result as $row)
			{
					
			$photo        =  $row['photo'];  
			$admincode    =  $row['username'];
			$username     =  $row['username'];
			$password     =  $row['password'];
			$fullname     =  $row['fullname'];
			$phone        =  $row['phone'];
			$gender       =  $row['gender'];  
			$acct_level   =  $row['acct_level']; 
			$registrar    =  $row['registrar'];
			$sub_start    =  $row['date_reg'];
 
 
			}
	 
	 
   
	         
	 
		 }
 
} 
else 
{
	 header("Location: index.php");
}


?>