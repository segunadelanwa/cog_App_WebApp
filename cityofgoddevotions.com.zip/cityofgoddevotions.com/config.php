<?php
ob_start();
session_start();


require"phpmailer/PHPMailerAutoload.php";
$current_datetime = date("Y-m-d");
$time = date("H:i:s", STRTOTIME(date('h:i:sa')));


class Loader{
	
	
	
	
	var $host; 
	var $username;
	var $password;
	var $database;
	var $connect;
	var $home_page;
	var $query;
	var $data;
	var $statement;
	var $filedata;
	
	
	
	function __construct()
	{
		
 
 /*
       	$this->host = 'localhost';
		$this->username = 'cityofg1_adminuser';
		$this->password = 'cityofg1_cog_church_db@@@123123';
		$this->database = 'cityofg1_cog_church_db'; 
		
	
	
 */	
       	$this->host = 'localhost';
		$this->username = 'root';
		$this->password = '';
		$this->database = 'cityofg1_cog_church_db'; 
		
	
		
	  
		$this->connect = new PDO("mysql:host=$this->host; dbname=$this->database", "$this->username", "$this->password");
       
	 
	}

		function execute_query()
	{
		$this->statement = $this->connect->prepare($this->query);
		$this->statement->execute($this->data);
	}
  

  

	function total_row()
	{
		$this->execute_query();
		return $this->statement->rowCount();
	}

	function query_result()
	{
		$this->execute_query();
		return $this->statement->fetchAll();
	}

 
  
			function send_email($receiver_email, $subject, $body)
			{
				
			$mail = new PHPMailer;

			//$mail->IsSMTP();

			//$mail->Host = 'smtp host';

			//$mail->Port = '587'; 

			//$mail->SMTPAuth = true;

			//$mail->Username = '';

			//$mail->Password = '';

			//$mail->SMTPSecure = '';
            $mail->SMTPDebug = 0;  
			$mail->setFrom('noreply@cityofgoddevotions.com', 'CAC CITY OF GOD DEVOTION');

			$mail->FromName = 'CAC CITY OF GOD DEVOTION';
			
			$mail->AddReplyTo = 'surpport@cityofgoddevotions.com';

			$mail->AddAddress($receiver_email, '');

			$mail->IsHTML(true);

			$mail->Subject = $subject;

			$mail->Body = $body;
			
			$mail->AddEmbeddedImage('all_photo/logo.png', 'logo', 'all_photo/logo.png'); 

			$mail->Send();		
			}	
			
			
			function redirect()
			{
				header('location:  index.php');
				exit;
			}

			function admin_session_private()
			{
				if(!isset($_SESSION['admin_id']))
				{
					$this->redirect('login.php');
				}
			}

			function admin_session_public()
			{
				if(isset($_SESSION['admin_id']))
				{
					$this->redirect('index.php');
				}
			}

 

	 
			function VoucherCode()
			{
				
					 
					$auth_code  = mb_strimwidth(rand(), 0, 6); 
					$new_name="COG$auth_code";
					
						return $new_name;
			
			}

				//30days(sep,apr,jun,nov) 28(feb)

			function January($day)
			{
				$result="";
				
				
				$su = ["01", "08", "15", "22", "29"];
				$mo = ["02", "09", "16", "23", "30"];
				$tu = ["03", "10", "17", "24", "31"];
				$we = ["04", "11", "18", "25"];
				$th = ["05", "12", "19", "26"];
				$fr = ["06", "13", "20", "27"];
				$sa = ["07", "14", "21", "28"];

				 // TRUE
				
				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY JANUARY";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY JANUARY";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY JANUARY";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY JANUARY";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY JANUARY";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY JANUARY";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY JANUARY";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function February($day)
			{
				$result="";
				
				
				$su = ["",   "05", "12", "19", "26"];
				$mo = ["",   "06", "13", "20", "27"];
				$tu = ["",   "07", "14", "21", "28"];
				$we = ["01", "08", "15", "22"];
				$th = ["02", "09", "16", "23"];
				$fr = ["03", "10", "17", "24"];
				$sa = ["04", "11", "18", "25"];

				 // TRUE
				
				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY FEBRUARY";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY FEBRUARY";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY FEBRUARY";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY FEBRUARY";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY FEBRUARY";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY FEBRUARY";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY FEBRUARY";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function March($day)
			{
				$result="";
				
				
				$su = ["",   "05", "12", "19", "26"];
				$mo = ["",   "06", "13", "20", "27"];
				$tu = ["",   "07", "14", "21", "28"];
				$we = ["01", "08", "15", "22", "29"];
				$th = ["02", "09", "16", "23", "30"];
				$fr = ["03", "10", "17", "24", "31"];
				$sa = ["04", "11", "18", "25"];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY MARCH";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY MARCH";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY MARCH";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY MARCH";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY MARCH";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY MARCH";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY MARCH";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function April($day)
			{
				$result="";
				
				
				$su = ["30", "02", "09", "16", "23"];
				$mo = ["",   "03", "10", "17", "24"];
				$tu = ["",   "04", "11", "18", "25"];
				$we = ["",   "05", "12", "19", "26"];
				$th = ["",   "06", "13", "20", "27"];
				$fr = ["",   "07", "14", "21", "28"];
				$sa = ["01", "08", "15", "22", "29"];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY APRIL";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY APRIL";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY APRIL";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY APRIL";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY APRIL";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY APRIL";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY APRIL";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function May($day)
			{
				$result="";
				
				
				$su = ["",   "07", "14", "21", "28"];
				$mo = ["01", "08", "15", "22", "29"];
				$tu = ["02", "09", "16", "23", "30"];
				$we = ["03", "10", "17", "24", "31"];
				$th = ["04", "11", "18", "25", ""];
				$fr = ["05", "12", "19", "26", ""];
				$sa = ["06", "13", "20", "27", ""];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY MAY";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY MAY";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY MAY";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY MAY";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY MAY";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY MAY";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY MAY";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function Jun($day)
			{
				$result="";
				
				
				$su = ["",   "06", "13", "20", "27"];
				$mo = ["",   "07", "14", "21", "28"];
				$tu = ["01", "08", "15", "22", "29"];
				$we = ["02", "09", "16", "23", "30"];
				$th = ["03", "10", "17", "24", ""];
				$fr = ["04", "11", "18", "25", ""];
				$sa = ["05", "12", "19", "26", ""];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY JUN";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY JUN";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY JUN";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY JUN";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY JUN";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY JUN";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY JUN";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function July($day)
			{
				$result="";
				
				
				$su = ["30", "02", "09", "16", "23"];
				$mo = ["31", "03", "10", "17", "24"];
				$tu = ["",   "04", "11", "18", "25"];
				$we = ["",   "05", "12", "19", "26"];
				$th = ["",   "06", "13", "20", "27"];
				$fr = ["",   "07", "14", "21", "28"];
				$sa = ["01", "08", "15", "22", "29"];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY JULY";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY JULY";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY JULY";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY JULY";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY JULY";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY JULY";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY JULY";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function August($day)
			{
				$result="";
				
				
				$su = ["",   "06", "13", "20", "27"];
				$mo = ["",   "07", "14", "21", "28"];
				$tu = ["01", "08", "15", "22", "29"];
				$we = ["02", "09", "16", "23", "30"];
				$th = ["03", "10", "17", "24", "31"];
				$fr = ["04", "11", "18", "25",   ""];
				$sa = ["05", "12", "19", "26",   ""];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY AUGUST";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY AUGUST";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY AUGUST";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY AUGUST";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY AUGUST";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY AUGUST";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY AUGUST";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function September($day)
			{
				$result="";
				
				
				$su = ["00", "03", "10", "17", "24"];
				$mo = ["00", "04", "11", "18", "25"];
				$tu = ["00", "05", "12", "19", "26"];
				$we = ["00", "06", "13", "20", "27"];
				$th = ["00", "07", "14", "21", "28"];
				$fr = ["01", "08", "15", "22", "29"];
				$sa = ["02", "09", "16", "23", "30"];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY SEPTEMBER";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY SEPTEMBER";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY SEPTEMBER";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY SEPTEMBER";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY SEPTEMBER";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY SEPTEMBER";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY SEPTEMBER";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function October($day)
			{
				$result="";
				
				
				$su = ["01", "08", "15", "22", "29"];
				$mo = ["02", "09", "16", "23", "30"];
				$tu = ["03", "10", "17", "24", "31"];
				$we = ["04", "11", "18", "25", "00"];
				$th = ["05", "12", "19", "26", "00"];
				$fr = ["06", "13", "20", "27", "00"];
				$sa = ["07", "14", "21", "28", "00"];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY OCTOBER";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY OCTOBER";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY OCTOBER";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY OCTOBER";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY OCTOBER";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY OCTOBER";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY OCTOBER";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function November($day)
			{
				$result="";
				
				
				$su = ["00", "05", "12", "19", "26"];
				$mo = ["00", "06", "13", "20", "27"];
				$tu = ["00", "07", "14", "21", "28"];
				$we = ["01", "08", "15", "22", "29"];
				$th = ["02", "09", "16", "23", "30"];
				$fr = ["03", "10", "17", "24", "00"];
				$sa = ["04", "11", "18", "25", "00"];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY OCTOBER";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY OCTOBER";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY OCTOBER";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY OCTOBER";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY OCTOBER";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY OCTOBER";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY OCTOBER";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}

			function December($day)
			{
				$result="";
				
				
				$su = ["31", "03", "10", "17", "24"];
				$mo = ["00", "04", "11", "18", "25"];
				$tu = ["00", "05", "12", "19", "26"];
				$we = ["00", "06", "13", "20", "27"];
				$th = ["00", "07", "14", "21", "28"];
				$fr = ["01", "08", "15", "22", "29"];
				$sa = ["02", "09", "16", "23", "30"];

				
                if(in_array($day, $su)){
					
				  $result = $result = "$day, SUNDAY DECEMBER";
				
				}else if(in_array($day, $mo)){
				 
				  $result = $result = "$day, MONDAY DECEMBER";
				 
				}elseif(in_array($day, $tu)){
				
				 $result = $result = "$day, TUESDAY DECEMBER";
				
				}else if(in_array($day, $we)){
				
				 $result = $result = "$day, WEDNESDAY DECEMBER";
				
				}else if(in_array($day, $th)){
				
				 $result = $result = "$day, THURSDAY DECEMBER";
				
				}else if(in_array($day, $fr)){
				
				 $result = $result = "$day, FRIDAY DECEMBER";
				
				}else if(in_array($day, $sa)){
				
				 $result = $result = "$day, SATURDAY DECEMBER";
				
				}
				
				
				
	
			return $result;
				
				 

			
			}


			function DevotionDate($day, $month)
			{
				$result="";
				
				if($month == "01"){
					
				$result = $this->January($day);
				
				}else if($month == "02"){
					
				$result = $this->February($day);
				
				}else if($month == "03"){
					
				$result = $this->March($day);
				
				}else if($month == "04"){
					
				$result = $this->April($day);
				
				}else if($month == "05"){
					
				$result = $this->May($day);
				
				}else if($month == "06"){
					
				$result = $this->Jun($day);
				
				}else if($month == "07"){
					
				$result = $this->July($day);
				
				}else if($month == "08"){
					
				$result = $this->August($day);
				
				}else if($month == "09"){
					
				$result = $this->September($day);
				
				}else if($month == "10"){
					
				$result = $this->October($day);
				
				}else if($month == "11"){
					
				$result = $this->November($day);
				
				}else if($month == "12"){
					
				$result = $this->December($day);
				
				}
				
					
 

					return $result;

			
			}
	
		 
			function Upload_file($user)
			{
				
				$serverPhoto = $this->ProfilePhotoUpdate($user);
				
				
				if(!empty($this->filedata['name']))
				{
					$extension = pathinfo($this->filedata['name'], PATHINFO_EXTENSION);

					$new_name = uniqid() . '.' . $extension;

					$_source_path = $this->filedata['tmp_name'];

					$target_path = 'all_photo/' . $new_name;

					if(move_uploaded_file($_source_path, $target_path)){
						
						
						$this->query ="UPDATE `login_table` SET   
						`photo`  = '$new_name'		 
						WHERE `login_table`.`username` = '$user' ";
						$this->execute_query();
						
						
						
						if($serverPhoto == 'placeholder.jpg'){
							
						 							
						}else{
							
                         unlink("all_photo/$serverPhoto");

						}							
							
							
						return 1;
						
					}else{
						
						return 0;
					}

					
				}
			}
	
 			function Upload_Image()
			{
				
				 
				
				if(!empty($this->filedata['name']))
				{
					$extension = pathinfo($this->filedata['name'], PATHINFO_EXTENSION);

					$new_name = uniqid() . '.' . $extension;

					$_source_path = $this->filedata['tmp_name'];

					$target_path = 'all_photo/' . $new_name;

					move_uploaded_file($_source_path, $target_path);
						
													
						return $new_name;
						
				
					
				}
			}
	
 

 			function ProfilePhotoUpdate($user)
			{
				$this->query = "SELECT * FROM `login_table` WHERE `login_table`.`username` ='$user' ";
		 		$result = $this->query_result();

				foreach($result as $row)
				{
					$output = $row['photo'];
				}
				return $output;
			}

 
 			function CheckDublicateDevotionDate($date)
			{
				 
				 
				$this->query = "SELECT * FROM `english_devotions` WHERE `current_day` = '$date' ";
		 
				$output = $this->total_row();
				 
				return $output;
			}

		
 			function FetctAllAdmin()
			{
				 
				 
				$this->query = "SELECT * FROM `login_table` ";
		 
				$output = $this->query_result();
				 
				return $output;
			}



 			function CheckSubscriber($email)
			{
				 
				 
				$this->query = "SELECT * FROM `book_subscriber` WHERE `book_subscriber`.`email` = '$email' ";
		 
				$output = $this->total_row();
				 
				return $output;
			}
 			function FetchAllActiveSubscriber()
			{
				 
				 
				$this->query = "SELECT * FROM `book_subscriber` WHERE `book_subscriber`.`status` = 'active' ";
		 
				$output = $this->query_result();
				 
				return $output;
			}
		
 			function FetchAllPassiveSubscriber()
			{
				 
				 
				$this->query = "SELECT * FROM `book_subscriber` WHERE `book_subscriber`.`status` = 'passive' ";
		 
				$output = $this->query_result();
				 
				return $output;
			}


 			function FetchVoucher()
			{
				 
				 
				$this->query = "SELECT * FROM `voucher` ";
		 
				$output = $this->query_result();
				 
				return $output;
			}


 			function DisplayEbookActiveSubsciber()
			{
				 
				 
				$this->query = "SELECT * FROM `e_books` WHERE `e_books`.`status` = 'active' ";
		 
				$output = $this->total_row();
				 
				return $output;
			}
		
 			function DisplayEbookPassiveSubsciber()
			{
				 
				 
				$this->query = "SELECT * FROM `e_books` WHERE `e_books`.`status` = 'passive' ";
		 
				$output = $this->total_row();
				 
				return $output;
			}

		
		function DisplayTotalVoucherRow()
			{
				 
				 
				$this->query = "SELECT * FROM `voucher` ";
		 
				$output = $this->total_row();
				 
				return $output;
			}


			function CheckCouponValidity($couponCode)
			{
				 // CHECK ID couponCode HAS EXPIRED
				 	$current_date  = date('Y-m-d');	

				$this->query = "SELECT * FROM `voucher` WHERE `voucher`.`voucher_code` = '$couponCode' AND 	`voucher`.`voucher_date_expire < '$current_date'";
		 
				$output = $this->total_row();
				
				if($output == 1){
				 
				  return  $result = "1";
				
				}else{
					
			      return  $result= "2";
				
				}
			}

		
		function DisplayAdminRow()
			{
				 
				 
				$this->query = "SELECT * FROM `login_table` ";
		 
				$output = $this->total_row();
				 
				return $output;
			}

		
		
		function admin_signup_action()
			{
				 
			$current_date  = date('Y-m-d');		 
		$form_data = array(
		  
			':tier3'            => 'tier3.jpg',
			':placeholder'      => 'placeholder.jpg',
			':current_date'     =>  $current_date,
			':registrar'        =>  $_POST['registrar'],
			':gender'           =>  $_POST['gender'],
			':phone'            =>  $_POST['phone'],
			':fullname'         =>  $_POST['fullname'],
			':username'         =>  $_POST['user_email_address'],
			':user_password'    =>  password_hash(trim($_POST['password']), PASSWORD_DEFAULT)
			);
			

							
					//if($acct_level === 'tier1' )
					//{
						


							$query = "
							INSERT INTO login_table 
							(photo,username,password,fullname,phone,gender,acct_level,registrar,date_reg)
							VALUES
							(:placeholder, :username, :user_password,:fullname,:phone,:gender,:tier3,:registrar,:current_date )
							";
							

							$statement = $this->connect->prepare($query);
						 
								if($statement->execute($form_data))
								{
												
					 
					 
					
								    $subject = 'CAC CITY OF GOD ADMIN SETUP' ;
								
								     $body = "
										<div style='width:100%;height:5px;background: #c908bd'></div><br> 
										<div style='font-size:14px;color:black;font-family:lucida sans;'>
										
											 <center >
												 <img src=\'cid:logo\'  style='text-align:center;height:150px;'/> <br> 
												 <h1>CAC CITY OG GOD </h1>
												 <h1>Staff / Admin Registeration </h1>
											 </center><br>

														 
										   <p>
										   Hi ".$_POST['fullname']." your registeration account has been setup. Please find below your login details
										   </p>
										   
											<p>
												 Username: ".$_POST['fullname']."  <br />
												 Password: ".$_POST['password']."  <br />
												 
											</p>
											
											
											<span style='font-size:15px;text-align:center;'>COG ADMIN OPERATOR ACCOUNT SETUP <span><br>
											<div style='width:100%;height:5px;background: blue'></div>  
											
											
											</div><br><br>
										 </div>			
										 ";
					
						              $this->send_email($_POST['user_email_address'], $subject, $body);
		 

										$output = array(
											'success'		=>	'success',
											'feedback'		=>	'COG Admin operator account setup successfully!!.Check your email for login details'
										);

						

							}
							else
							{
								
									$output = array(
										'success'		=>	'failed',
										'feedback'		=>	"Newtwork error"
									);
							}
		/*			}
					else
					{
						
							$output = array(
								'success'		=>	'failed',
								'feedback'		=>	"Sorry $acc_fullname, your are not authorized to setup an account "
							);
					}
*/

				return $output;
			}

		

  		
		public function DevotionsDay()
			{

             //$date = date('Y-m-d');
             $date = '2023-01-01';
		 

			return $date;		


			}

	
  		    public function FetchApiDevotionsEngOffline()
			{

                $i=0;
                $this->query ="SELECT * FROM `english_devotions` ";
                
                $result = $this->query_result();
                foreach($result as $row){
                
                $data[$i] = $row;
                $i++;
                }
                


		     	return $data;		


			}
			
			
  		public function FetchApiDevotionsEng($todayDevotion)
			{

             

                $rand = rand(0, 12);	
                $randPhoto ="https://cityofgoddevotions.com/devotion_Photo/nature$rand.jpg";
				
				$this->query ="SELECT * FROM `english_devotions` WHERE current_day ='$todayDevotion' ";
				
                $total_row = $this->total_row();
				if($total_row > 0){
				
	            $result = $this->query_result();
        				foreach($result as $row)
        				{
        				 
        				  
        							$data[] = array(
        							   'headline'      =>  $row['headline'],
        							   'topic'         =>  $row['topic'],
        							   'text'          =>  $row['text'],
        							   'text_reading'  =>  $row['text_reading'],
        							   'prayer'        =>  $row['prayer'],
        							   'imgurl'        =>  $randPhoto
        							   
        							    
        							    );
        				}
        				
        				
        				
				}else{
					$data = "no-data";
				}

			return $data;		


			}
			
			
  		public function FetchApiDevotionsYor($todayDevotion)
			{

             

                $rand = rand(0, 12);	
                $randPhoto ="https://cityofgoddevotions.com/devotion_Photo/nature$rand.jpg";
				
				$this->query ="SELECT * FROM `yoruba_devotions` WHERE current_day ='$todayDevotion' ";
				
                $total_row = $this->total_row();
				if($total_row > 0){
				
	            $result = $this->query_result();
        				foreach($result as $row)
        				{
        				 
        				  
        							$data[] = array(
        							   'headline'      =>  $row['headline'],
        							   'topic'         =>  $row['topic'],
        							   'text'          =>  $row['text'],
        							   'text_reading'  =>  $row['text_reading'],
        							   'prayer'        =>  $row['prayer'],
        							   'imgurl'        =>  $randPhoto
        							   
        							    
        							    );
        				}
        				
        				
        				
				}else{
					$data = "no-data";
				}

			return $data;		


			}
			
			
			
	
  		public function FetchAllDevotionsEng($todayDevotion)
			{

             
				//$i=0;
				$this->query ="SELECT * FROM `english_devotions` WHERE current_day ='$todayDevotion' ";
				
                $total_row = $this->total_row();
				if($total_row > 0){
				
	            $data = $this->query_result();
				
				}else{
					$data = "no-data";
				}

			return $data;		


			}
	
  		public function FetchAllDevotionsYor($todayDevotion)
			{

             
				//$i=0;
				$this->query ="SELECT * FROM `yoruba_devotions` WHERE current_day ='$todayDevotion' ";
				
                $total_row = $this->total_row();
				if($total_row > 0){
				
	            $data = $this->query_result();
				
				}else{
					$data = "no-data";
				}

			return $data;		


			}

			public function ApiFetchAllEbookPhoto()
			{

             
             
                $this->query ="SELECT * FROM `e_books` ";
                $ebookPhotoUrl ="https://cityofgoddevotions.com/all_photo/";
                $result = $this->query_result();
                foreach($result as $row)
                {
                
                    $ebookPhot =$row['ebook_photo'];
                    
                	$data[] = array(
                	    
                	   'ebook_photo'  =>  "$ebookPhotoUrl/$ebookPhot",
                	   'book_name'    =>  $row['book_name'],
                	   'id'           =>  $row['id']
                	   
                	    );
                }
                
                
                
                
                return $data;		 
   	
	 
	 

			}
			
			
			public function FetchClickedEbbok($ebookid)
			{

             
             
                $this->query ="SELECT * FROM `e_books` WHERE  `id` ='$ebookid' ";
                $ebookPhotoUrl ="https://cityofgoddevotions.com/all_photo/";
                $result = $this->query_result();
                foreach($result as $row)
                {
                
                    $ebookPhot =$row['ebook_photo'];
                    
                	$data[] = array(
                	    
                	   'ebook_photo'    =>  "$ebookPhotoUrl/$ebookPhot",
                	   'book_name'      =>  $row['book_name'],
                	   'about'          =>  $row['about'],
                	   'ebook_id'       =>  $row['ebook_id'],
                	   'book_name'      =>  $row['book_name'],
                	   'table_content'  =>  $row['table_content'],
                	   'introduction'   =>  $row['introduction'],
                	   'chapter_0'      =>  $row['chapter_0'],
                	   'chapter_1'      =>  $row['chapter_1'],
                	   'chapter_2'      =>  $row['chapter_2'],
                	   'chapter_3'      =>  $row['chapter_3'],
                	   'chapter_4'      =>  $row['chapter_4'],
                	   'chapter_5'      =>  $row['chapter_5'],
                	   'chapter_6'      =>  $row['chapter_6'],
                	   'chapter_7'      =>  $row['chapter_7'],
                	   'chapter_8'      =>  $row['chapter_8'],
                	   'chapter_9'      =>  $row['chapter_9']
                	   
                	    );
                }
                
                
                
                
                return $data;		 
   	
	 
	 

			}

			
			public function FetchAllEbookPhoto()
			{

             
			 
				$this->query ="SELECT * FROM `e_books`";
			    $data = $this->query_result();
				
			    return $data;		


			}


			public function FetchFullEbook($ebook_id)
			{

             
			 
				$this->query ="SELECT * FROM `e_books` WHERE id='$ebook_id'  ";
			    $data = $this->query_result();
				
			    return $data;		


			}
			
			
			public function ApiFetchEbookSubscriber($email,$phone,$fullname)
			{

             
             
                $this->query ="SELECT * FROM `e_books` "; 
                $result = $this->query_result();
                foreach($result as $row)
                {
                
                    $voucher_code =$row['voucher_code'];
                    
                	$data[] = array(
                	     
                	   'voucher_code'    =>  $row['voucher_code'],
                	   'phone'           =>  $row['phone'],
                	   'email'           =>  $row['email'],
                	   'fullname'        =>  $row['fullname'],
                	   'sub_date'        =>  $row['sub_date'],
                	   'sub_expire'      =>  $row['sub_expire'],
                	   'status'          =>  $row['status'],
                	   'date'            =>  $row['date'],
                	   
                	    );
                }
                
                
                
                
                return $data;		 
   	
	 
	 

			}
	
 }
 
 /*
 			foreach($output as $row){

				$data[$i] = $row;
				$i++;
				}
 */
?>
 
 
 
 
 
 
 
 
 
 